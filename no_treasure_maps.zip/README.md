# No Treasure Maps

This datapack replaces Treasure Maps with Hearts of the Sea in shipwreck chests.

## Install

Drop the zip file into the `datapacks/` folder of your save.

## Build

To build the datapack from source,
switch into the directory that this README is in and run

    zip -r no_treasure_maps.zip *

